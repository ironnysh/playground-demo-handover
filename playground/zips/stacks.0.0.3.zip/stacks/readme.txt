=== Stacks ===
Contributors: wordpressdotorg
Requires at least: 6.2
Tested up to: 6.2
Requires PHP: 5.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Stack your story. This theme is designed specifically to create slide decks that can be used as a presentation. The "Stacks" pattern can be included on any page or post.

== Changelog ==

= 0.0.3 =
* Initial release

== Copyright ==

Stacks WordPress Theme.
Stacks is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
